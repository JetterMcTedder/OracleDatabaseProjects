import React from 'react';
import logo from '../images/logo.png';const Header = () => {
return (
    <header>

    </header>
    );
};export default Header;
